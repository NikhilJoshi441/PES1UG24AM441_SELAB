"""
Lab 7 - hardened version of processor.py
Name : Nikhil Suhas Joshi
SRN  : PES1UG24AM441

Every function now validates its input and rejects bad input with a clean
ValueError instead of crashing with AttributeError / KeyError /
ZeroDivisionError / OverflowError.
"""
import math
import re

_QUOTA_RE = re.compile(r"^([0-9]+)(MB|GB|TB)$")


def parse_storage_quota(quota_str):
    """
    Parses storage quota string with unit suffix into Gigabytes (GB).
    Format: '<digits><2-letter unit>' (e.g. '500MB', '20GB', '2TB').
    Raises ValueError for anything else.
    """
    if not isinstance(quota_str, str):
        raise ValueError("quota must be a string")
    match = _QUOTA_RE.match(quota_str.strip().upper())
    if match is None:
        raise ValueError(f"invalid quota format: {quota_str!r}")
    value = int(match.group(1))
    unit = match.group(2)
    multipliers = {"MB": 0.001, "GB": 1.0, "TB": 1000.0}
    try:
        gb_total = value * multipliers[unit]
    except OverflowError:
        raise ValueError("quota value too large")
    return f"Quota: {gb_total:.2f} GB"


def compute_compression_ratio(size_metric_str):
    """
    Computes compression ratio: raw_bytes / compressed_bytes.
    Format: 'raw_bytes:compressed_bytes' (e.g. '1024:256').
    Raises ValueError for malformed input or a non-positive compressed size.
    """
    if not isinstance(size_metric_str, str):
        raise ValueError("size metric must be a string")
    parts = size_metric_str.split(":")
    if len(parts) != 2:
        raise ValueError("expected format 'raw_bytes:compressed_bytes'")
    raw_bytes = float(parts[0])          # ValueError on non-numeric text
    comp_bytes = float(parts[1])
    if not (math.isfinite(raw_bytes) and math.isfinite(comp_bytes)):
        raise ValueError("sizes must be finite numbers")
    if raw_bytes < 0 or comp_bytes <= 0:
        raise ValueError("raw must be >= 0 and compressed must be > 0")
    ratio = raw_bytes / comp_bytes
    if not math.isfinite(ratio):
        raise ValueError("ratio out of range")
    return round(ratio, 2)


def lookup_bandwidth_tier_rate(tier_descriptor):
    """
    Looks up rate per GB for egress traffic using the first 3 letters of the
    tier name. Raises ValueError for unknown or too-short tier names.
    """
    if not isinstance(tier_descriptor, str):
        raise ValueError("tier descriptor must be a string")
    prefix = tier_descriptor.strip().upper()[:3]
    tier_rates = {"HOT": 0.08, "COL": 0.05, "ARC": 0.02}
    if prefix not in tier_rates:
        raise ValueError(f"unknown tier: {tier_descriptor!r}")
    return tier_rates[prefix]


def main():
    print("==== Running parse_storage_quota ====")
    q_input = input("Enter quota (e.g. 500MB, 10GB, 2TB): ")
    try:
        print(parse_storage_quota(q_input))
    except ValueError as e:
        print("Error:", e)

    print("\n==== Running compute_compression_ratio ====")
    c_input = input("Enter raw:compressed bytes (e.g. 1024:256): ")
    try:
        print("Compression Ratio:", compute_compression_ratio(c_input))
    except ValueError as e:
        print("Error:", e)

    print("\n==== Running lookup_bandwidth_tier_rate ====")
    t_input = input("Enter tier descriptor (e.g. HOT_TIER, COLD, ARCHIVE): ")
    try:
        print("Rate per GB: $", lookup_bandwidth_tier_rate(t_input))
    except ValueError as e:
        print("Error:", e)


if __name__ == "__main__":
    main()
