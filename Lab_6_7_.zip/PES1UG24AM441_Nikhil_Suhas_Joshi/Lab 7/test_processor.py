"""
Lab 7: Fuzz Testing with Hypothesis
Name : Nikhil Suhas Joshi
SRN  : PES1UG24AM441

Each test throws arbitrary text (and None) at a function. A clean rejection of
bad input (ValueError) is acceptable; ANY other exception type (AttributeError,
KeyError, ZeroDivisionError, TypeError, ...) is an unhandled crash -> test fails.
"""
import pytest
from hypothesis import given, strategies as st
from processor import parse_storage_quota, compute_compression_ratio, lookup_bandwidth_tier_rate


@given(st.text() | st.none())
def test_parse_storage_quota_no_crash(s):
    try:
        parse_storage_quota(s)
    except ValueError:
        pass  # graceful rejection of malformed input is fine
    except Exception as e:
        pytest.fail(f"parse_storage_quota({s!r}) crashed with {type(e).__name__}: {e}")


@given(st.text() | st.none())
def test_compute_compression_ratio_safe(s):
    try:
        compute_compression_ratio(s)
    except ValueError:
        pass
    except Exception as e:
        pytest.fail(f"compute_compression_ratio({s!r}) crashed with {type(e).__name__}: {e}")


@given(st.text() | st.none())
def test_lookup_bandwidth_tier_rate_safe(s):
    try:
        lookup_bandwidth_tier_rate(s)
    except ValueError:
        pass
    except Exception as e:
        pytest.fail(f"lookup_bandwidth_tier_rate({s!r}) crashed with {type(e).__name__}: {e}")
