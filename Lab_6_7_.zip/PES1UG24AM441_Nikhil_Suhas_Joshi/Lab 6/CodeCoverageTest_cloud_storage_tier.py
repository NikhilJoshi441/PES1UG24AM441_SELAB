"""
Lab 6: Code Coverage test cases
Name : Nikhil Suhas Joshi
SRN  : PES1UG24AM441
Run  : coverage run -m pytest CodeCoverageTest_cloud_storage_tier.py
       coverage report -m
"""
import pytest
from cloud_storage_tier import process_storage_tenants, monitor_replication_latency


def tenant(tier="hot", buckets=None, active=True, vault=False):
    return {"account_active": active, "tier": tier, "has_backup_vault": vault,
            "buckets": buckets if buckets is not None else []}


def bucket(size_gb=100, corrupted=False, egress_gb=0):
    return {"size_gb": size_gb, "corrupted": corrupted, "egress_gb": egress_gb}



def test_single_active_hot_tenant():
    result = process_storage_tenants([tenant("hot", [bucket(100, False, 50)])], 10.0)
    assert result == {"total_billed": 2.5, "status": "BILLED"}


def test_invalid_input_raises():
    with pytest.raises(ValueError):
        process_storage_tenants("not a list", 10.0)


def test_inactive_account_skipped():
    assert process_storage_tenants([tenant("hot", [bucket(100)], active=False)], 10.0)["status"] == "ZERO_USAGE"


def test_cool_and_archive_tiers_with_vault():
    tenants = [tenant("cool", [bucket(200)]), tenant("archive", [bucket(200)], vault=True)]
    assert process_storage_tenants(tenants, 5.0)["total_billed"] == 9.0  # 3.0 + 1.0 + 5.0


def test_unknown_tier_flagged():
    assert process_storage_tenants([tenant("platinum", [bucket(100)])], 10.0)["status"] == "ZERO_USAGE"


def test_bad_size_corrupted_discount_and_egress():
    buckets = [bucket(0), bucket(100, True), bucket(1000, False, 200)]
    result = process_storage_tenants([tenant("hot", buckets)], 0)
    assert result["total_billed"] == 30.5  # 22.5 + (200-100)*0.08


def test_corrupted_archive_breaks_and_zeroes():
    result = process_storage_tenants([tenant("archive", [bucket(200), bucket(100, True)])], 0)
    assert result["total_billed"] == 0.0


def test_audit_flagged():
    buckets = [bucket(0) for _ in range(5)] + [bucket(100)]
    assert process_storage_tenants([tenant("hot", buckets)], 0)["status"] == "AUDIT_FLAGGED"


def test_monitor_all_paths():
    assert monitor_replication_latency([]) == "NO_DATA"
    assert monitor_replication_latency([[100, 250, 100]]) == "SYNCED"
    assert monitor_replication_latency([[100, 250, 300]]) == "SYNC_LAG_ALERT"
