"""
Lab 6: Branch Coverage test cases
Name : Nikhil Suhas Joshi
SRN  : PES1UG24AM441
Run  : coverage run --branch -m pytest BranchCoverageTest_cloud_storage_tier.py
       coverage report -m
"""
import pytest
from cloud_storage_tier import process_storage_tenants, monitor_replication_latency


def tenant(tier="hot", buckets=None, active=True, vault=False):
    return {"account_active": active, "tier": tier, "has_backup_vault": vault,
            "buckets": buckets if buckets is not None else []}


def bucket(size_gb=100, corrupted=False, egress_gb=0):
    return {"size_gb": size_gb, "corrupted": corrupted, "egress_gb": egress_gb}


# ---------------- Example test (given) ----------------
def test_single_active_hot_tenant():
    tenants = [tenant("hot", [bucket(100, False, 50)])]
    result = process_storage_tenants(tenants, 10.0)
    assert result["total_billed"] == 2.5
    assert result["status"] == "BILLED"


# ---------------- Input validation ----------------
def test_invalid_tenants_not_a_list():
    with pytest.raises(ValueError):
        process_storage_tenants("not a list", 10.0)


def test_invalid_negative_support_fee():
    with pytest.raises(ValueError):
        process_storage_tenants([], -1.0)


def test_empty_tenants_list_is_zero_usage():
    assert process_storage_tenants([], 10.0) == {"total_billed": 0.0, "status": "ZERO_USAGE"}


# ---------------- Account / tier handling ----------------
def test_inactive_account_is_skipped():
    result = process_storage_tenants([tenant("hot", [bucket(100)], active=False)], 10.0)
    assert result == {"total_billed": 0.0, "status": "ZERO_USAGE"}


def test_missing_account_active_key_defaults_to_inactive():
    result = process_storage_tenants([{"tier": "hot", "buckets": [bucket(100)]}], 10.0)
    assert result["status"] == "ZERO_USAGE"


def test_default_tier_is_hot_and_default_buckets_empty():
    # No "tier" key -> hot; no "buckets" key -> []; vault fee still applies
    result = process_storage_tenants([{"account_active": True, "has_backup_vault": True}], 7.5)
    assert result == {"total_billed": 7.5, "status": "BILLED"}


def test_cool_tier_rate():
    result = process_storage_tenants([tenant("cool", [bucket(200)])], 0)
    assert result["total_billed"] == 3.0  # 200 * 0.015
    assert result["status"] == "BILLED"


def test_archive_tier_rate():
    result = process_storage_tenants([tenant("archive", [bucket(200)])], 0)
    assert result["total_billed"] == 1.0  # 200 * 0.005
    assert result["status"] == "BILLED"


def test_unknown_tier_is_flagged_and_skipped():
    result = process_storage_tenants([tenant("platinum", [bucket(100)])], 10.0)
    assert result == {"total_billed": 0.0, "status": "ZERO_USAGE"}


# ---------------- Bucket handling ----------------
def test_zero_size_bucket_is_flagged_and_skipped():
    result = process_storage_tenants([tenant("hot", [bucket(0), bucket(100)])], 0)
    assert result["total_billed"] == 2.5


def test_negative_size_bucket_is_flagged_and_skipped():
    result = process_storage_tenants([tenant("hot", [bucket(-5)])], 0)
    assert result["status"] == "ZERO_USAGE"


def test_corrupted_bucket_non_archive_costs_nothing_but_continues():
    # Corrupted hot bucket adds 0; the following healthy bucket is still billed
    result = process_storage_tenants([tenant("hot", [bucket(100, True), bucket(100)])], 0)
    assert result["total_billed"] == 2.5
    assert result["status"] == "BILLED"


def test_corrupted_non_archive_still_charges_egress():
    # corrupted hot bucket (0 storage) + 150GB egress -> (150-100)*0.08 = 4.0
    result = process_storage_tenants([tenant("hot", [bucket(100, True, 150)])], 0)
    assert result["total_billed"] == 4.0


def test_corrupted_archive_bucket_zeroes_charge_and_breaks():
    # First bucket billed (1.0), second is corrupted -> charge reset to 0 and loop breaks,
    # so the third bucket is never processed.
    buckets = [bucket(200), bucket(100, True, 500), bucket(200)]
    result = process_storage_tenants([tenant("archive", buckets)], 0)
    assert result == {"total_billed": 0.0, "status": "ZERO_USAGE"}


def test_large_bucket_gets_ten_percent_discount():
    result = process_storage_tenants([tenant("hot", [bucket(1000)])], 0)
    assert result["total_billed"] == 22.5  # 1000 * 0.025 * 0.9


def test_bucket_of_exactly_500gb_gets_no_discount():
    result = process_storage_tenants([tenant("hot", [bucket(500)])], 0)
    assert result["total_billed"] == 12.5  # 500 * 0.025


def test_egress_over_100gb_is_charged_on_excess_only():
    result = process_storage_tenants([tenant("hot", [bucket(100, False, 200)])], 0)
    assert result["total_billed"] == 10.5  # 2.5 + (200-100)*0.08


def test_egress_of_exactly_100gb_is_free():
    result = process_storage_tenants([tenant("hot", [bucket(100, False, 100)])], 0)
    assert result["total_billed"] == 2.5


# ---------------- Backup vault ----------------
def test_backup_vault_adds_fixed_support_fee():
    result = process_storage_tenants([tenant("hot", [bucket(100)], vault=True)], 10.0)
    assert result["total_billed"] == 12.5


def test_no_backup_vault_no_fee():
    result = process_storage_tenants([tenant("hot", [bucket(100)], vault=False)], 10.0)
    assert result["total_billed"] == 2.5


# ---------------- Multi-tenant totals & final status ----------------
def test_multiple_tenants_are_summed():
    tenants = [
        tenant("hot", [bucket(100)]),
        tenant("cool", [bucket(200)]),
        tenant("archive", [bucket(200)], vault=True),
    ]
    result = process_storage_tenants(tenants, 5.0)
    assert result["total_billed"] == 11.5  # 2.5 + 3.0 + (1.0 + 5.0)
    assert result["status"] == "BILLED"


def test_audit_flagged_when_more_than_four_flagged_buckets():
    buckets = [bucket(0) for _ in range(5)] + [bucket(100)]
    result = process_storage_tenants([tenant("hot", buckets)], 0)
    assert result == {"total_billed": 2.5, "status": "AUDIT_FLAGGED"}


def test_exactly_four_flagged_buckets_is_not_audit_flagged():
    buckets = [bucket(0) for _ in range(4)] + [bucket(100)]
    result = process_storage_tenants([tenant("hot", buckets)], 0)
    assert result["status"] == "BILLED"


# ---------------- monitor_replication_latency ----------------
def test_monitor_empty_matrix_no_data():
    assert monitor_replication_latency([]) == "NO_DATA"


def test_monitor_none_matrix_no_data():
    assert monitor_replication_latency(None) == "NO_DATA"


def test_monitor_two_consecutive_spikes_alert():
    assert monitor_replication_latency([[100, 250, 300]]) == "SYNC_LAG_ALERT"


def test_monitor_alert_on_later_node():
    assert monitor_replication_latency([[100, 120], [250, 260]]) == "SYNC_LAG_ALERT"


def test_monitor_single_spike_is_not_alert():
    assert monitor_replication_latency([[100, 250, 100]]) == "SYNCED"


def test_monitor_non_consecutive_spikes_reset_streak():
    assert monitor_replication_latency([[250, 100, 250, 100, 250]]) == "SYNCED"


def test_monitor_latency_of_exactly_200_is_not_a_spike():
    assert monitor_replication_latency([[200, 200, 200]]) == "SYNCED"


def test_monitor_streak_does_not_carry_across_nodes():
    assert monitor_replication_latency([[250], [250]]) == "SYNCED"


def test_monitor_empty_node_logs():
    assert monitor_replication_latency([[]]) == "SYNCED"
