# Issues Found in `radio_schedule.py`

Original file: Pylint **2.41/10**, Bandit 3 issues (2 Medium, 1 Low), Flake8 4 issues.
Fixed file: Pylint **10.00/10**, Bandit **0 issues**, Flake8 **0 issues**.

Line numbers refer to the **original** file. Rows are ordered by severity.
"Severity" is my own judgement of real-world impact; where Bandit rated it differently, that is noted.

| Issue | Type | Line(s) | Description | Fix Approach |
| ----- | ---- | ------- | ----------- | ------------ |
| SQL injection in `addSlot` | Security (Bandit B608, CWE-89) | 11 | **High** (Bandit: Medium). The INSERT is built with `%` string formatting, so user input becomes part of the SQL. Confirmed: a show called `Rock 'n' Roll` crashes with `OperationalError`, and a crafted name such as `x'); DROP TABLE slots;--` could alter or destroy data. | Use a parameterised query: `VALUES (?, ?, ?, ?)` with a tuple of values, as `removeSlot` already does. |
| Arbitrary code execution via `eval` | Security (Bandit B307, CWE-78; Pylint W0123) | 21 | **High** (Bandit: Medium, High confidence). `overlapFree` passes a string straight to `eval`, so any caller can run arbitrary Python (verified with `__import__('os')`). It is also a poor design: the "formula" is just a time comparison. | Remove `eval`. Replace with `overlap_free(first_start_hour, first_minutes, second_start_hour)`, which does the arithmetic directly (`start*60 + minutes <= next_start*60`). |
| Stale global counter `booked_minutes` (logic bug) | Bug / Design | 6, 10, 12, 27, 32 | **Medium**. The counter is only ever increased. `removeSlot` never decrements it, so after the demo it reports 105 minutes when only 60 are booked. `morningShows` also depends on it for a pointless guard (`if booked_minutes > 0`), so it can return `[]` while the database still holds morning shows. | Delete the global. Derive the figure from the database with `SELECT COALESCE(SUM(minutes), 0)` in `total_booked_minutes()`, so it can never drift out of sync. Drop the guard in `morning_shows`. |
| Hard-coded password | Security (Bandit B105, CWE-259) | 5 | **Low** (Bandit: Low). `STUDIO_PASSWORD = "onair2024"` is a credential committed to source control. It is also never used anywhere in the program. | Removed the dead credential. If one were needed, read it from an environment variable (`os.environ`) or a secrets store, never from source. |
| Use of `global` statement | Maintainability (Pylint W0603) | 10 | **Medium**. `addSlot` mutates module-level state, which makes the code hard to test and is the root cause of the stale-counter bug above. | Removed the global. The database connection is now created by `create_connection()` and passed explicitly into each function. |
| Module-level side effects (DB created and `main()` run on import) | Design | 3-4, 43 | **Medium**. Importing the module opens a database and runs the demo. This makes unit testing impossible without the demo executing. | Moved DB setup into `create_connection()` and guarded the entry point with `if __name__ == "__main__":`. |
| Overly broad exception handler | Maintainability (Pylint W0718) | 22 | **Medium**. `except Exception: return False` hid every error, including bad input, and silently reported "not free". | Disappears with `eval`: plain integer arithmetic has nothing to catch. Errors now surface instead of being swallowed. |
| Function names not snake_case | Style (Pylint C0103) | 9, 15, 19, 26, 31 | **Low**. `addSlot`, `slotLabel`, `overlapFree`, `morningShows`, `removeSlot` use camelCase, against PEP 8. (Line 6, `booked_minutes`, was also flagged as a badly named constant.) | Renamed to `add_slot`, `slot_label`, `overlap_free`, `morning_shows`, `remove_slot`. |
| Missing module and function docstrings | Documentation (Pylint C0114, C0116) | 1, 9, 15, 19, 26, 31, 35 | **Low**. No docstrings anywhere, so purpose and return values are undocumented. | Added a module docstring and a one-line docstring to every function. |
| Lines too long | Style (Pylint C0301, Flake8 E501) | 4, 11, 27 | **Low**. Lines of 118, 135 and 110 characters (limits: 100 Pylint, 79 Flake8). | Split SQL strings across lines with implicit concatenation and wrapped calls. |
| Multiple statements on one line | Style (Pylint C0321, Flake8 E701) | 27 | **Low**. `if ...: return [...]` on a single line hurts readability. The guard was removed entirely. | Removed the guard; the query is a normal multi-line statement. |
| `%` / `.format()` string formatting | Style (Pylint C0209) | 11, 16 | **Low**. Old-style formatting where f-strings are preferred. | `slot_label` now uses an f-string; the SQL no longer uses string formatting at all (parameterised). |
| Magic number `12` | Maintainability | 27 | **Low** (not reported by any tool). The "morning" cut-off was hard-coded inside the SQL. | Named constant `NOON = 12`, passed in as a query parameter. |

## Fixed

All 13 documented issues are fixed (the brief requires at least 4). Rerunning the tools confirms it.

| Tool | Before | After |
| ---- | ------ | ----- |
| Pylint | 2.41/10 (22 messages) | 10.00/10 (0 messages) |
| Bandit | 3 issues (2 Medium, 1 Low) | 0 issues |
| Flake8 | 4 issues | 0 issues |

## Behaviour check

The program still does its job. Original output:

```
Sunrise Beats hosted by Vik
True ['Sunrise Beats']
```

is reproduced exactly by the fixed version, followed by two extra lines that show the counter bug is gone:

```
Booked minutes: 105
Booked minutes after removal: 60
```
