"""Programme schedule for a radio station.

Books show slots, lists the morning shows, checks timing and removes slots.
"""
import sqlite3

NOON = 12


def create_connection():
    """Create an in-memory database containing an empty ``slots`` table."""
    conn = sqlite3.connect(":memory:")
    conn.execute(
        "CREATE TABLE slots ("
        "id INTEGER PRIMARY KEY, show TEXT, host TEXT, "
        "start_hour INTEGER, minutes INTEGER)"
    )
    return conn


def add_slot(conn, show, host, start_hour, minutes):
    """Book a show slot and return the id of the new slot."""
    cursor = conn.execute(
        "INSERT INTO slots (show, host, start_hour, minutes) "
        "VALUES (?, ?, ?, ?)",
        (show, host, start_hour, minutes),
    )
    return cursor.lastrowid


def slot_label(show, host):
    """Return a human-readable label for a slot."""
    return f"{show} hosted by {host}"


def overlap_free(first_start_hour, first_minutes, second_start_hour):
    """Return True if the first slot ends before the second one starts."""
    first_end = first_start_hour * 60 + first_minutes
    return first_end <= second_start_hour * 60


def morning_shows(conn):
    """Return the names of all shows that start before noon."""
    rows = conn.execute(
        "SELECT show FROM slots WHERE start_hour < ?", (NOON,)
    )
    return [row[0] for row in rows]


def total_booked_minutes(conn):
    """Return the total number of minutes currently booked."""
    row = conn.execute(
        "SELECT COALESCE(SUM(minutes), 0) FROM slots"
    ).fetchone()
    return row[0]


def remove_slot(conn, slot_id):
    """Remove a slot; return True if a slot was actually deleted."""
    cursor = conn.execute("DELETE FROM slots WHERE id = ?", (slot_id,))
    return cursor.rowcount > 0


def main():
    """Run a short demonstration of the schedule."""
    conn = create_connection()
    add_slot(conn, "Sunrise Beats", "Vik", 7, 60)
    second_id = add_slot(conn, "Midday Talk", "Anu", 13, 45)
    print(slot_label("Sunrise Beats", "Vik"))
    print(overlap_free(7, 60, 13), morning_shows(conn))
    print("Booked minutes:", total_booked_minutes(conn))
    remove_slot(conn, second_id)
    print("Booked minutes after removal:", total_booked_minutes(conn))
    conn.close()


if __name__ == "__main__":
    main()
