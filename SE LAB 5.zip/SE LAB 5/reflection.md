# Reflection

> **Note:** the lab handout was not in the repository, so the four questions below are my best reconstruction of the usual Lab 5 reflection prompts. Check them against your handout and adjust the headings if the wording differs.

## 1. Which tool found the most issues, and which found the most important ones?

Pylint found the most (22 messages, score 2.41/10), but almost all of them were style or documentation issues such as naming, docstrings and line length. Bandit found only three, yet those were the ones that matter: SQL injection, `eval` on a string, and a hard-coded password. Flake8 found four, all of which Pylint also reported. So the quantity came from Pylint and the severity came from Bandit. I would not trust any single tool: the most damaging logic bug in the file (the `booked_minutes` counter never going down after `removeSlot`) was reported by **none** of them.

## 2. Were there any false positives or findings you disagreed with?

Mostly no, but some deserve context. Bandit rated the hard-coded password Low, which is fair here because the string is never used, but a real credential in source control is serious regardless of use, since it stays in git history. In the other direction, Bandit rated SQL injection and `eval` as Medium, whereas I would call both High: `eval` on caller-supplied input allows arbitrary code execution. The severity is a heuristic about likelihood and confidence, not a measure of the damage if it is exploited. Pylint's "too many/long lines" and docstring warnings are real but cosmetic. They are the kind of finding people reasonably silence in practice, and they carry the same weight in the score as genuine problems.

## 3. What did static analysis miss, and what does that tell you about its limits?

It missed the logic bugs. The global counter was reported only as a style problem (`global-statement`), not as the actual defect that it reports 105 booked minutes when 60 remain. Static tools do not know what the program is *supposed* to do, so they cannot tell that a number goes stale. They also cannot see that `overlapFree` is misdesigned: a function that evaluates a string is flagged for being dangerous, but nothing says it should not exist. I found these by running the code and reading it, then confirmed them with small tests (for example, the apostrophe in `Rock 'n' Roll` crashing the INSERT). Static analysis is a good first filter, not a substitute for testing and code review.

## 4. How would you use these tools in a real project, and what did you learn about fixing issues?

I would run Flake8 and Pylint in a pre-commit hook and in CI, so style issues never accumulate, and run Bandit on every pull request, failing the build on Medium and above. Fixing taught me that one root cause often explains several findings. Removing `eval` also removed the broad `except Exception`, and removing the global also removed the stale-counter bug and made the functions testable. The right fix was to redesign (pass the connection in, query the database for the total) rather than to silence warnings with `# noqa` or `# pylint: disable`. A score of 10/10 is a good sign but not proof of correctness, which is why I also tested the fixed code directly, including a SQL injection string and an empty database.
